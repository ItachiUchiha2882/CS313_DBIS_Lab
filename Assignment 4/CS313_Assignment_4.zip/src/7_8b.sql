INSERT INTO section 
    VALUES('CS-101', '1', 'Fall', 2007, 'Watson', '100', 'E');
INSERT INTO section 
    VALUES('CS-190', '1', 'Fall', 2007, 'Watson', '100', 'B');

INSERT INTO teaches VALUES('10101', 'CS-101', '1', 'Fall', '2007');
INSERT INTO teaches VALUES('10101', 'CS-190', '1', 'Fall', '2007');

INSERT INTO takes VALUES('20001', 'CS-101', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20002', 'CS-101', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20003', 'CS-101', '1', 'Fall', 2007, 'A');
INSERT INTO takes VALUES('20004', 'CS-101', '1', 'Fall', 2007, 'B');
INSERT INTO takes VALUES('20005', 'CS-101', '1', 'Fall', 2007, 'B+');
INSERT INTO takes VALUES('20006', 'CS-101', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20007', 'CS-101', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20008', 'CS-101', '1', 'Fall', 2007, 'A');
INSERT INTO takes VALUES('20009', 'CS-101', '1', 'Fall', 2007, 'B');
INSERT INTO takes VALUES('20010', 'CS-101', '1', 'Fall', 2007, 'B+');
INSERT INTO takes VALUES('20011', 'CS-101', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20012', 'CS-101', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20013', 'CS-101', '1', 'Fall', 2007, 'A');
INSERT INTO takes VALUES('20014', 'CS-101', '1', 'Fall', 2007, 'B');
INSERT INTO takes VALUES('20015', 'CS-101', '1', 'Fall', 2007, 'B+');
INSERT INTO takes VALUES('20016', 'CS-101', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20017', 'CS-101', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20018', 'CS-101', '1', 'Fall', 2007, 'A');

INSERT INTO takes VALUES('20002', 'CS-190', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20001', 'CS-190', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20003', 'CS-190', '1', 'Fall', 2007, 'A');
INSERT INTO takes VALUES('20004', 'CS-190', '1', 'Fall', 2007, 'B');
INSERT INTO takes VALUES('20005', 'CS-190', '1', 'Fall', 2007, 'B+');
INSERT INTO takes VALUES('20006', 'CS-190', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20007', 'CS-190', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20008', 'CS-190', '1', 'Fall', 2007, 'A');
INSERT INTO takes VALUES('20009', 'CS-190', '1', 'Fall', 2007, 'B');
INSERT INTO takes VALUES('20010', 'CS-190', '1', 'Fall', 2007, 'B+');
INSERT INTO takes VALUES('20011', 'CS-190', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20012', 'CS-190', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20013', 'CS-190', '1', 'Fall', 2007, 'A');
INSERT INTO takes VALUES('20014', 'CS-190', '1', 'Fall', 2007, 'B');
INSERT INTO takes VALUES('20015', 'CS-190', '1', 'Fall', 2007, 'B+');
INSERT INTO takes VALUES('20016', 'CS-190', '1', 'Fall', 2007, 'A+');
INSERT INTO takes VALUES('20017', 'CS-190', '1', 'Fall', 2007, 'A+');