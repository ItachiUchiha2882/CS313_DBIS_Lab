USE university;
SELECT DATABASE(); -- to see selected database. 