CREATE USER 'universityDB0004'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON university.* TO 'universityDB0004'@'localhost';