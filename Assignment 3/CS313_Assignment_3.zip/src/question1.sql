CREATE USER 'lab3'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON lab3.* TO 'lab3'@'localhost';
CREATE DATABASE lab3;