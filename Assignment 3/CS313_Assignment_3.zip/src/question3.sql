INSERT INTO part VALUES ('00001', 'Wheel', 'Black', 1.5);
INSERT INTO supplier VALUES ('10001', 'Robert', 'Tokyo', 'Tokyo Bank');
INSERT INTO shipment 
    VALUES ('20001', '00001', '10001', '2020-05-22', 15, 1000);