-- creating Library database
CREATE DATABASE Library;
SHOW DATABASES;