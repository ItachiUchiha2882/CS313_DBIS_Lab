/**
 * 
 */
/**
 * @author apple
 *
 */
module lab_5 {
	requires java.sql;
}